package com.vang.confirmbookservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfirmbookserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
