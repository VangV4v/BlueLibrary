package com.vang.confirmbookservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfirmbookserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfirmbookserviceApplication.class, args);
	}

}
